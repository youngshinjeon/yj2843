console.log('this works')

// [1] get text

// [2] add event listener


// [3] define the event handler

